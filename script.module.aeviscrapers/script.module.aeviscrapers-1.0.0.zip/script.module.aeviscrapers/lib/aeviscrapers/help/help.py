# -*- coding: utf-8 -*-
"""
	Aeviscrapers Module
"""

from aeviscrapers.modules.control import addonPath, addonVersion, joinPath
from aeviscrapers.windows.textviewer import TextViewerXML


def get(file):
	aeviscrapers_path = addonPath()
	aeviscrapers_version = addonVersion()
	helpFile = joinPath(aeviscrapers_path, 'lib', 'aeviscrapers', 'help', file + '.txt')
	r = open(helpFile, 'r', encoding='utf-8', errors='ignore')
	text = r.read()
	r.close()
	heading = '[B]FenomScrapers -  v%s - %s[/B]' % (aeviscrapers_version, file)
	windows = TextViewerXML('textviewer.xml', aeviscrapers_path, heading=heading, text=text)
	windows.run()
	del windows