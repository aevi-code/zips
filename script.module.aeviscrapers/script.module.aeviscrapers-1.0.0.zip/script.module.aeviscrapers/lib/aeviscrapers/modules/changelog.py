# -*- coding: utf-8 -*-
"""
	Aeviscrapers Module
"""

from aeviscrapers.modules.control import addonPath, addonVersion, joinPath
from aeviscrapers.windows.textviewer import TextViewerXML


def get():
	aeviscrapers_path = addonPath()
	aeviscrapers_version = addonVersion()
	changelogfile = joinPath(aeviscrapers_path, 'changelog.txt')
	r = open(changelogfile, 'r', encoding='utf-8', errors='ignore')
	text = r.read()
	r.close()
	heading = '[B]FenomScrapers -  v%s - ChangeLog[/B]' % aeviscrapers_version
	windows = TextViewerXML('textviewer.xml', aeviscrapers_path, heading=heading, text=text)
	windows.run()
	del windows