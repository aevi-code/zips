from __future__ import print_function

from future import standard_library
standard_library.install_aliases()
from builtins import str
from builtins import range
from datetime import datetime

import json
import operator
import routing
import sys
import urllib.request, urllib.parse, urllib.error
from urllib.parse import urlencode
from urllib.parse import parse_qsl
import http.cookiejar
import xbmcgui
import xbmcplugin
import xbmcaddon

#Home dir definition
PLUGIN_ID = 'plugin.video.aevi'
MEDIA_URL = 'special://home/addons/{0}/resources/media/'.format(PLUGIN_ID)

addon = xbmcaddon.Addon('plugin.video.aevi')
aeviurl = 'https://aevi.stream'
username = addon.getSetting('username')
password = addon.getSetting('password')
maxval = addon.getSetting('maxval')


# Initialize the authentication
cj = http.cookiejar.CookieJar()
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
opener.addheaders = [
    ('Accept', 'application/json, text/javascript, */*; q=0.01'),
    ('Content-Type', 'application/json; charset=UTF-8'),
    ('Connection', 'keep-alive'),
]

login_data = urllib.parse.urlencode(
    {'username': username, 'password': password, 'remember_me': 'on'}).encode("utf-8")
# Authenticate

opener.open(aeviurl + '/login/authenticate', login_data)

cookiestring = str(cj).split(" ")
# print(cookiestring)
#cookie = cookiestring[1].split("__cfduid=")
sessionid = cookiestring[1].split("JSESSIONID=")
remember_me = cookiestring[5].split("streama_remember_me=")

VIDEOS = {'Search': [],
          'Shows': [],
          'Movies': [],
          'Genres': [],
          'Recently Added': [],
          'Aevi Recommends': []}

# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

# Initialize the authentication
cj = http.cookiejar.CookieJar()
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
opener.addheaders = [
    ('Accept', 'application/json, text/javascript, */*; q=0.01'),
    ('Content-Type', 'application/json; charset=UTF-8'),
    ('Connection', 'keep-alive'),
]

login_data = urllib.parse.urlencode(
    {'username': username, 'password': password, 'remember_me': 'on'}).encode("utf-8")
# Authenticate

opener.open(aeviurl + '/login/authenticate', login_data)


def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs))


def get_categories():
    # return the list of categories
    return iter(VIDEOS.keys())


def get_videos(category, showid):
    if category == 'Shows':
        items = opener.open(aeviurl + '/dash/listShows.json?max=' + maxval)
        videolist = json.loads(items.read())
        return videolist["list"]
    elif category == 'Episodes':
        items = opener.open(
            aeviurl + '/tvShow/EpisodesForTvShow.json?id=' + showid)
        videolist = json.loads(items.read())
        return videolist
    elif category == 'Movies':
        items = opener.open(aeviurl + '/dash/listMovies.json?max=' + maxval)
        videolist = json.loads(items.read())
        return videolist["list"]
    elif category == 'Recently Added':
        items = opener.open(aeviurl + '/dash/listMovies.json?sort=dateCreated&order=desc')
        videolist = json.loads(items.read())
        return videolist['list']

    elif category == 'Aevi Recommends':
        items = opener.open(aeviurl + '/dash/listNewReleases.json')
        videolist = json.loads(items.read())
        return videolist

    elif category == 'Genres':
        items = opener.open(aeviurl + '/dash/listGenres.json')
        videolist = json.loads(items.read())
        return videolist
    elif category == 'GenreFind':
        items = opener.open(aeviurl + '/dash/listMovies.json?genre=' + showid + '&max=' + maxval)
        videolist = json.loads(items.read())
        return videolist['list']

    elif category == 'Search':
        dialog = xbmcgui.Dialog()
        searchstring = dialog.input('Search:', type=xbmcgui.INPUT_ALPHANUM)
        searchstring = urllib.parse.quote_plus(searchstring)
        items = opener.open(
            aeviurl + '/dash/searchMedia.json?query=' + searchstring)
        videolist = json.loads(items.read())
        return videolist
    else:
        items = []
        videolist = json.loads(items.read())
        return videolist


def list_categories():
    # Get video categories
    categories = get_categories()
    # Iterate through categories
    for category in categories:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=category)
        list_item.setInfo('video', {'title': category, 'genre': category})
        # Create a URL for a plugin recursive call.
        url = get_url(action='listing', category=category, showid=0)
        # is_folder = True means that this item opens a sub-list of lower level items.
        is_folder = True
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    xbmcplugin.endOfDirectory(_handle)


def list_videos(category, showid):
    # Get the list of videos in the category.
    videos = get_videos(category, showid)

    if category == 'Shows':
        for video in videos:
            list_item = xbmcgui.ListItem(label=video['name']+' ('+str(video['first_air_date'][:4]+')'), label2='IMDB Rating: '+str(video['vote_average'])+'\n\n'+video['overview'])
            list_item.setInfo(
					'video', {'plot': 'Release Date: '+str(video['first_air_date'])+'\n'+'IMDB Rating: '+str(video['vote_average'])+'\n\n'+video['overview']})
            try:
                list_item.setArt({'thumb': 'https://image.tmdb.org/t/p/w500//' +
                                  video['poster_path'], 'icon': 'https://image.tmdb.org/t/p/w500//' + video['poster_path']})
            except:
                foo = 23
            id = video['id']
            url = get_url(action='listing', category='Episodes', showid=id)
            is_folder = True
            xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    elif category == 'Episodes':
        for video in videos:
            if video['hasFile'] == 1:
                list_item = xbmcgui.ListItem(
                    label='S'+str(video['season_number'])+'E'+str(video['episode_number'])+' '+video['name'], label2=video['overview'])
                list_item.setInfo('video', {'title': 'S'+str(video['season_number'])+'E'+str(
                    video['episode_number']) + ' ' + video['name'], 'genre': video['overview'], 'plot': video['overview']})
                try:
                    list_item.setArt({'thumb': 'https://image.tmdb.org/t/p/w300//' + video['still_path'], 'icon': 'https://image.tmdb.org/t/p/w300//' + video['still_path'], 'fanart': 'https://image.tmdb.org/t/p/w300//' + video['still_path']})
                except:
                    list_item.setArt({'thumb': MEDIA_URL +'noimage.png', 'icon': MEDIA_URL +'noimage.png', 'fanart': MEDIA_URL +'noimage.png'})
                list_item.setProperty('IsPlayable', 'true')
                id = video['id']
                url = get_url(action='play', video=id)
                is_folder = False
                xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    elif category == 'Movies':
        # Iterate through videos.
        for video in videos:
            # Create a list item with a text label and a thumbnail image.
            list_item = xbmcgui.ListItem(
                label=video['title']+' '+str(video['release_date'][:4]), label2='IMDB Rating: '+str(video['vote_average'])+'\n\n'+video['overview'])
            # Set additional info for the list item.

            list_item.setInfo(
                'video', {'title': video['title']+' ('+str(video['release_date'][:4]+')'), 'genre': video['overview'], 'plot': 'Release Date: '+str(video['release_date'])+'\n'+'IMDB Rating: '+str(video['vote_average'])+'\n\n'+video['overview']})
            # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
            # Here we use the same image for all items for simplicity's sake.
            # In a real-life plugin you need to set each image accordingly.
            try:
                list_item.setArt({'thumb': 'https://image.tmdb.org/t/p/w500//' +
                                  video['poster_path'], 'icon': 'https://image.tmdb.org/t/p/w500//' + video['poster_path'], 'fanart': 'https://image.tmdb.org/t/p/w1280//' + video['backdrop_path']})
            except:
                foo = 23
                list_item.setArt({'thumb': MEDIA_URL +'noimage.png', 'icon': MEDIA_URL +'noimage.png', 'fanart': MEDIA_URL +'noimage.png'})
            # Set 'IsPlayable' property to 'true'.
            list_item.setProperty('IsPlayable', 'true')
            # Create a URL for a plugin recursive call.
            id = video['id']

            url = get_url(action='play', video=id)

            # Add the list item to a virtual Kodi folder.
            is_folder = False
            # Add our item to the Kodi virtual folder listing.
            xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)

#    elif category == 'Generic Videos':
#        for video in videos:
#            # Create a list item with a text label and a thumbnail image.
#            list_item = xbmcgui.ListItem(label=video['title'])
            # Set additional info for the list item.
#            list_item.setInfo(
#                'video', {'title': video['title'], 'genre': video['overview']})
#            list_item.setProperty('IsPlayable', 'true')
#            id = video['id']

#            url = get_url(action='play', video=id)
#            is_folder = False
#            xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)




#NEW & FIXED Genres
    elif category == 'Genres':
        for video in videos:
            list_item = xbmcgui.ListItem(label=video['name'])
            id = video['id']
            url = get_url(action='listing', category='GenreFind', showid=id)
            is_folder = True
            xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)


    elif category == 'GenreFind':
        # Iterate through videos.
        for video in videos:
            # Create a list item with a text label and a thumbnail image.
            list_item = xbmcgui.ListItem(label=video['title']+' '+str(video['release_date'][:4]), label2='IMDB Rating: '+str(video['vote_average'])+'\n\n'+video['overview'])
            # Set additional info for the list item.

            list_item.setInfo(
                'video', {'title': video['title']+' ('+str(video['release_date'][:4]+')'), 'genre': video['overview'], 'plot': 'Release Date: '+str(video['release_date'])+'\n'+'IMDB Rating: '+str(video['vote_average'])+'\n\n'+video['overview']})
            # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
            # Here we use the same image for all items for simplicity's sake.
            # In a real-life plugin you need to set each image accordingly.
            try:
                list_item.setArt({'thumb': 'https://image.tmdb.org/t/p/w500//' +
                                  video['poster_path'], 'icon': 'https://image.tmdb.org/t/p/w500//' + video['poster_path'], 'fanart': 'https://image.tmdb.org/t/p/w1280//' + video['backdrop_path']})
            except:
                foo = 23
                list_item.setArt({'thumb': MEDIA_URL +'noimage.png', 'icon': MEDIA_URL +'noimage.png', 'fanart': MEDIA_URL +'noimage.png'})
            # Set 'IsPlayable' property to 'true'.
            list_item.setProperty('IsPlayable', 'true')
            # Create a URL for a plugin recursive call.
            id = video['id']

            url = get_url(action='play', video=id)

            # Add the list item to a virtual Kodi folder.
            is_folder = False
            # Add our item to the Kodi virtual folder listing.
            xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)


    elif category == 'Recently Added':
        for video in videos:
            list_item = xbmcgui.ListItem(label=video['title'])
            is_folder = False
            list_item.setProperty('IsPlayable', 'true')

            list_item.setInfo('video', {'title': video['title']+' ('+str(video['release_date'][:4]+')'), 'genre': video['genre'][0]['name'], 'plot': 'Release Date: '+str(video['release_date'])+'\n'+'IMDB Rating: '+str(video['vote_average'])+'\n\n'+video['overview']})

            list_item.setArt({'thumb': 'https://image.tmdb.org/t/p/w500//' + video['poster_path'], 'icon': 'https://image.tmdb.org/t/p/w500//' + video['poster_path'], 'fanart': 'https://image.tmdb.org/t/p/w1280//' + video['poster_path']})

            id = video['id']
            url = get_url(action='play', video=id)

            xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
            xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_NONE)


    elif category == 'Aevi Recommends':
        for video in videos:
            try:
                list_item = xbmcgui.ListItem(label=video['movie']['title'])
                id = video['movie']['id']
                url = get_url(action='play', video=id)
                is_folder = False
                list_item.setProperty('IsPlayable', 'true')

                list_item.setInfo('video', {'title': video['movie']['title']+' ('+str(video['movie']['release_date'][:4]+')'), 'genre': video['movie']['genre'][0]['name'], 'plot': 'Release Date: '+str(video['movie']['release_date'])+'\n'+'IMDB Rating: '+str(video['movie']['vote_average'])+'\n\n'+video['movie']['overview']})

                list_item.setArt({'thumb': 'https://image.tmdb.org/t/p/w500//' + video['movie']['poster_path'], 'icon': 'https://image.tmdb.org/t/p/w500//' + video['movie']['poster_path'], 'fanart': 'https://image.tmdb.org/t/p/w1280//' + video['movie']['poster_path']})

                xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
            except:
                foo = 23


            try:
                list_item = xbmcgui.ListItem(label=video['tvShow']['name'])
                id = video['tvShow']['id']
                url = get_url(action='listing', category='Episodes', showid=id)
                is_folder = True

                list_item.setInfo('video', {'title': video['tvShow']['name']+' ('+str(video['tvShow']['first_air_date'][:4]+')'), 'genre': video['tvShow']['overview'], 'plot': 'Release Date: '+str(video['tvShow']['first_air_date'])+'\n'+'IMDB Rating: '+str(video['tvShow']['vote_average'])+'\n\n'+video['tvShow']['overview']})

                list_item.setArt({'thumb': 'https://image.tmdb.org/t/p/w500//' + video['tvShow']['poster_path'], 'icon': 'https://image.tmdb.org/t/p/w500//' + video['tvShow']['poster_path'], 'fanart': 'https://image.tmdb.org/t/p/w1280//' + video['tvShow']['poster_path']})
                xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
            except:
                foo = 42

    elif category == 'Search':
        if len(videos['shows']) != 0:
            for i in range(0, len(videos['shows'])):
                list_item = xbmcgui.ListItem(label=videos['shows'][i]['name']+' ('+str(videos['shows'][i]['first_air_date'][:4]+')'), label2='IMDB Rating: '+str(videos['shows'][i]['vote_average'])+'\n\n'+videos['shows'][i]['overview'])
                id = videos['shows'][i]['id']
                url = get_url(action='listing', category='Episodes', showid=id)
                is_folder = True

                list_item.setInfo('video', {'title': videos['shows'][i]['name']+' ('+str(videos['shows'][i]['first_air_date'][:4]+')'), 'genre': videos['shows'][i]['overview'], 'plot': 'Release Date: '+str(videos['shows'][i]['first_air_date'])+'\n'+'IMDB Rating: '+str(videos['shows'][i]['vote_average'])+'\n\n'+videos['shows'][i]['overview']})

                list_item.setArt({'thumb': 'https://image.tmdb.org/t/p/w500//' + videos['shows'][i]['poster_path'], 'icon': 'https://image.tmdb.org/t/p/w500//' + videos['shows'][i]['poster_path'], 'fanart': 'https://image.tmdb.org/t/p/w1280//' + videos['shows'][i]['poster_path']})

                xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
        if len(videos['movies']) != 0:
            for i in range(0, len(videos['movies'])):
                list_item = xbmcgui.ListItem(label=videos['movies'][i]['title']+' ('+str(videos['movies'][i]['release_date'][:4]+')'), label2='IMDB Rating: '+str(videos['movies'][i]['vote_average'])+'\n\n'+videos['movies'][i]['overview'])
                id = videos['movies'][i]['id']
                url = get_url(action='play', video=id)
                is_folder = False
                list_item.setProperty('IsPlayable', 'true')

                list_item.setInfo('video', {'title': videos['movies'][i]['title']+' ('+str(videos['movies'][i]['release_date'][:4]+')'), 'genre': videos['movies'][i]['overview'], 'plot': 'Release Date: '+str(videos['movies'][i]['release_date'])+'\n'+'IMDB Rating: '+str(videos['movies'][i]['vote_average'])+'\n\n'+videos['movies'][i]['overview']})

                list_item.setArt({'thumb': 'https://image.tmdb.org/t/p/w500//' + videos['movies'][i]['poster_path'], 'icon': 'https://image.tmdb.org/t/p/w500//' + videos['movies'][i]['poster_path'], 'fanart': 'https://image.tmdb.org/t/p/w1280//' + videos['movies'][i]['poster_path']})


                xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)

    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)


def play_video(id):
    # Get the JSON for the corresponding video from Streama
    movie = opener.open(aeviurl + '/video/show.json?id=' + id)
    # Create the path from resulting info
    movie_json = json.loads(movie.read())
    path = aeviurl + movie_json['videoFiles'][0]['src']
    # if path contains aeviurl, append sessionid-cookie and remember_me-cookie for auth
    if path.find(aeviurl) != -1:
        path = path + '|Cookie=__cfduid=%3D' + '%3BJSESSIONID%3D' + sessionid[1] + \
            '%3Bstreama_remember_me%3D' + remember_me[1] + '%3B'
    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem(path=path)
    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)

def router(paramstring):
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    if params:
        if params['action'] == 'listing':
            # Display the list of videos in a provided category.
            list_videos(params['category'], params['showid'])
        elif params['action'] == 'play':
            # Play a video from a provided URL.
            play_video(params['video'])
        else:
            # If the provided paramstring does not contain a supported action
            # we raise an exception. This helps to catch coding errors,
            # e.g. typos in action names.
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        list_categories()


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    router(sys.argv[2][1:])
